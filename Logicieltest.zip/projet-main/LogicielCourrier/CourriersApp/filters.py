""""import django_filters
from .models import *

class CourrierFilter(django_filters.FilterSet):
    class Meta:
        model = Courrier
        fields = '__all__'"""