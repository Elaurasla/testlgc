from django.contrib import admin
from CourriersApp.models.my_model import Courrier

# Register your models here.
admin.site.register(Courrier)