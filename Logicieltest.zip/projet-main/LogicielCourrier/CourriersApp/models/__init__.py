from .my_model import models
from .my_model import Courrier
from . import models
