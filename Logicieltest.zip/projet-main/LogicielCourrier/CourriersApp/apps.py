from django.apps import AppConfig


class CourriersappConfig(AppConfig):
    name = 'CourriersApp'
