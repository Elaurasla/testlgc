from django.contrib.auth.models import AbstractUser, Group
from django.db import models
from django.contrib.auth.models import PermissionsMixin

class Shopper(AbstractUser):
    pass

